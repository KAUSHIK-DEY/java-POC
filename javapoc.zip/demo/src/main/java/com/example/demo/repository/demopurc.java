package com.example.demo.repository;

import org.springframework.data.repository.CrudRepository;

import com.example.demo.entity.purchase;

public interface demopurc extends CrudRepository<purchase,String> {

}
